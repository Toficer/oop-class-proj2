#include "file.h"
#include <QMessageBox>
#include <vector>

readFileD::readFileD(QWidget *parent) {
	setupUi(this);
}