#include "GalaxyUI.h"
#include "Star.h"
#include "Planet.h"
#include "Moon.h"
#include "AstronomicalObject.h"
#include "Galaxy.h"
#include "CosmicVoid.h"
#include "SpiralGalaxy.h"
#include "creationWindow.h"
#include <fstream>
#include <qpalette.h>
using namespace std;

void GalaxyUI::writeString(int x, vector <AstronomicalObject*> objects) {
	/*if (x >= objects.size()) {
		throw string("\n\nThere is no object of that number.\n\n");
	}*/

	ui.textWindow->append(QString::fromStdString(objects[x]->toInterface()));
}

GalaxyUI::GalaxyUI(QWidget *parent)
	: QMainWindow(parent)
{
	ui.setupUi(this);
	ui.listWidget->setCurrentRow(0);
	QObject::connect(window.createObjB, SIGNAL(clicked()), this, SLOT(createObject()));
	QObject::connect(readw.readObjB, SIGNAL(clicked()), this, SLOT(readFile()));
	QObject::connect(writew.readObjB, SIGNAL(clicked()), this, SLOT(writeFile()));
	QObject::connect(window.listWidget, SIGNAL(itemPressed(QListWidgetItem*)), this, SLOT(setObjectLines()));
	readAll();
}

void GalaxyUI::displayAll() {
	ui.textWindow->clear();
	ui.textWindow->append("Objects currently in the container:");
	ui.textWindow->append(QString::number(objects.size()));
	ui.textWindow->append(" ");
	for (int x = 0; x < this->objects.size(); x++) {
		writeString(x, objects);
	}
}

void GalaxyUI::setObjectLines() {

	int n = window.listWidget->currentRow() + 1;

	if (n == 1) {
		window.diameterEdit->setText("//////////////////////////////////////////////////////////");
		window.ageEdit->setText("//////////////////////////////////////////////////////////");
		window.starEdit->setText("//////////////////////////////////////////////////////////");
		window.armEdit->setText("//////////////////////////////////////////////////////////");
		window.lifeEdit->clear();
	}
	else if (n == 2) {
		window.diameterEdit->clear();
		window.ageEdit->clear();
		window.starEdit->clear();
		window.armEdit->setText("//////////////////////////////////////////////////////////");
		window.lifeEdit->setText("//////////////////////////////////////////////////////////");
	}
	else if (n == 3) {
		window.diameterEdit->clear();
		window.ageEdit->clear();
		window.starEdit->clear();
		window.armEdit->clear();
		window.lifeEdit->setText("//////////////////////////////////////////////////////////");
	}
}

void GalaxyUI::createObject() {
	ui.textWindow->clear();
	int type, diameter, age, star, arm, life;
	string name;

	type = window.listWidget->currentRow()+1;
	diameter = window.diameterEdit->text().toInt();
	age = window.ageEdit->text().toInt();
	star = window.starEdit->text().toInt();
	arm = window.armEdit->text().toInt();
	life = window.lifeEdit->text().toInt();

	if (window.nameEdit->text().toStdString().length() != 0) {
		name = window.nameEdit->text().toStdString();
	}
	else {
		name = "unnamed";
	}

	if (type == 1) {
		CosmicVoid *temp = new CosmicVoid(life);
		temp->setName(name);
		objects.push_back(temp);
		string s = "cosmic void: ";
		s += name;
		ui.listWidget->addItem(QString::fromStdString(s));
	}

	else if (type == 2) {
		Galaxy *temp = new Galaxy(diameter, star, age);
		temp->setName(name);
		objects.push_back(temp);
		string s = "galaxy: ";
		s += name;
		ui.listWidget->addItem(QString::fromStdString(s));
	}

	else if (type == 3) {
		SpiralGalaxy *temp = new SpiralGalaxy(diameter, star, age, arm);
		temp->setName(name);
		objects.push_back(temp);
		string s = "spiral galaxy: ";
		s += name;
		ui.listWidget->addItem(QString::fromStdString(s));
	}

	if (objects.size() == 1) {
		ui.listWidget->setCurrentRow(0);
	}
	
}

void GalaxyUI::deleteObject() {
	if (objects.size() > 0) {
		objects.erase(objects.begin() + ui.listWidget->currentRow());
		ui.listWidget->takeItem(ui.listWidget->currentRow());
	}
	else return;
}

void GalaxyUI::displaySelected() {
	ui.textWindow->clear();
	writeString(ui.listWidget->currentRow(), objects);
}

void GalaxyUI::objectCount() {
	ui.textWindow->clear();
	ui.textWindow->append("Objects currently in the container:");
	ui.textWindow->append(QString::number(objects.size()));
}

void GalaxyUI::openCreator() {
	window.listWidget->setCurrentRow(0);
	window.diameterEdit->setText("//////////////////////////////////////////////////////////");
	window.ageEdit->setText("//////////////////////////////////////////////////////////");
	window.starEdit->setText("//////////////////////////////////////////////////////////");
	window.armEdit->setText("//////////////////////////////////////////////////////////");
	window.lifeEdit->clear();
	window.nameEdit->clear();
	window.exec();

}

void GalaxyUI::openReading() {
	readw.exec();

}

void GalaxyUI::openWriting() {
	writew.exec();

}

void GalaxyUI::readFile() {
	
	string name = readw.lineEdit->text().toStdString();

	int s1 = 0;
	ifstream input;
	input.open(name);

	if (!input.is_open()) {
		ui.textWindow->clear();
		ui.textWindow->append(QString::fromStdString("File doesn't exist or couldn't be accessed."));
		return;
	}

	input >> s1;

	if (s1 == 1) {
		CosmicVoid *temp = new CosmicVoid();
		temp[0].readString(input);
		objects.push_back(temp);
		ui.textWindow->clear();
		ui.textWindow->append(QString::fromStdString("Object created."));
		string s = "cosmic void: ";
		s += temp[0].returnName();
		ui.listWidget->addItem(QString::fromStdString(s));
	}
	else if (s1 == 2) {
		Galaxy *temp = new Galaxy();
		temp[0].readString(input);
		objects.push_back(temp);
		ui.textWindow->clear();
		ui.textWindow->append(QString::fromStdString("Object created."));
		string s = "galaxy: ";
		s += temp[0].returnName();
		ui.listWidget->addItem(QString::fromStdString(s));
	}
	else if (s1 == 3) {
		SpiralGalaxy *temp = new SpiralGalaxy();
		temp[0].readString(input);
		objects.push_back(temp);
		ui.textWindow->clear();
		ui.textWindow->append(QString::fromStdString("Object created."));
		string s = "spiral galaxy: ";
		s += temp[0].returnName();
		ui.listWidget->addItem(QString::fromStdString(s));
	}
	else {
		ui.textWindow->clear();
		ui.textWindow->append(QString::fromStdString("File doesn't contain a recognized object."));
		return;
	}
	input.close();
}

void GalaxyUI::readAll() {
	int s1 = 0, num = 0, tmp=0;
	ifstream input;
	input.open("encyclopedia.txt");

	if (!input.is_open()) {
		ui.textWindow->clear();
		ui.textWindow->append(QString::fromStdString("Archive file doesn't exist or couldn't be accessed."));
		return;
	}
	
	input >> num;
	for (int i = 0; i < num; i++) {
		input >> s1;
		if (s1 == 1) {
			CosmicVoid *temp = new CosmicVoid();
			temp[0].readString(input);
			objects.push_back(temp);
			string s = "cosmic void: ";
			s += temp[0].returnName();
			ui.listWidget->addItem(QString::fromStdString(s));
		}
		else if (s1 == 2) {
			Galaxy *temp = new Galaxy();
			temp[0].readString(input);
			objects.push_back(temp);
			string s = "galaxy: ";
			s += temp[0].returnName();
			ui.listWidget->addItem(QString::fromStdString(s));
		}
		else if (s1 == 3) {
			SpiralGalaxy *temp = new SpiralGalaxy();
			temp[0].readString(input);
			objects.push_back(temp);
			string s = "spiral galaxy: ";
			s += temp[0].returnName();
			ui.listWidget->addItem(QString::fromStdString(s));
		}
	}
	input.close();
}

void GalaxyUI::writeAll() {
	ofstream output;
	output.open("encyclopedia.txt");

	if (!output.is_open()) {
		ui.textWindow->clear();
		ui.textWindow->append(QString::fromStdString("Archive file couldn't be created."));
		return;
	}
	output << objects.size() << "\n";
	for (int i = 0; i < objects.size(); i++) {
		output << *objects[i];
	}
	output.close();
}

void GalaxyUI::writeFile() {

	string name = writew.lineEdit->text().toStdString();

	ofstream output;
	output.open(name);

	if (!output.is_open()) {
		ui.textWindow->clear();
		ui.textWindow->append(QString::fromStdString("File couldn't be created."));
		return;
	}

	output << *objects[ui.listWidget->currentRow()];
	ui.textWindow->clear();
	ui.textWindow->append(QString::fromStdString("Object saved."));
	output.close();
}

void GalaxyUI::imageDisplay() {
	displaySelected();
	ui.label->setPixmap(QPixmap(QString::fromStdString(objects[ui.listWidget->currentRow()]->returnImage())));
	ui.label->show();
}