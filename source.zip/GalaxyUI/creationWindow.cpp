#include "creationWindow.h"
#include <QMessageBox>
#include <vector>

creationWindow::creationWindow(QWidget *parent) {
	setupUi(this);
}